<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="MyPortfolio">
    <meta name="author" content="Mehdi Druelle">
    <link rel="icon" href="../slidefolio/img/IrProfile.ico">

    <title>Med Slidefolio</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Add custom CSS here -->
    <link href="css/slidefolio.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
    <?php 
    include 'public_html/slidefolio/php/header.php';
    ?>
  <!-- Bootstrap core JavaScript -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery-scrolltofixed-min.js"></script>
    <script src="js/jquery.vegas.js"></script>
    <script src="js/jquery.mixitup.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/bootstrap.js"></script>


    <!-- Slideshow Background  -->
    <script>
        $.vegas('slideshow', {
            delay: 5000,
            backgrounds: [
                //{src: './img/Background/8 choses.jpg', fade: 2000},
                {
                    src: './img/Background/SocialLife.jpg',
                    fade: 4000
                },
                {
                    src: './img/Background/codage mac.jpeg',
                    fade: 2000
                },
                {
                    src: './img/Background/AllLanguages.jpg',
                    fade: 2000
                },
                {
                    src: './img/Background/ClavierAlum.jpg',
                    fade: 2000
                },
                {
                    src: './img/Background/ProgrammingArt.jpg',
                    fade: 2000
                },
                {
                    src: './img/Background/commande line.png',
                    fade: 2000
                },
                //{src: './img/Background/legodev.jpeg', fade: 2000},
                {
                    src: './img/Background/page de code.jpg',
                    fade: 2000
                },
                {
                    src: './img/Background/HeartRate.jpg',
                    fade: 2000
                },
                {
                    src: './img/Background/Java.jpeg',
                    fade: 2000
                },
                {
                    src: './img/Background/Java2.jpg',
                    fade: 2000
                }
                //{src: './img/Background/MyLife.jpeg', fade: 2000},
                //{src: './img/Background/mac.jpeg', fade: 2000}

            ]
        })('overlay', {
            src: './img/overlay.png'
        });
    </script>
    <!-- /Slideshow Background -->

    <!-- Mixitup : Grid -->
    <script>
        $(function () {
            $('#Grid').mixitup();
        });
    </script>
    <!-- /Mixitup : Grid -->

    <!-- Custom JavaScript for Smooth Scrolling - Put in a custom JavaScript file to clean this up -->
    <script>
        $(function () {
            $('a[href*=#]:not([href=#])').click(function () {
                if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') ||
                    location.hostname === this.hostname) {

                    var target = $(this.hash);
                    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                    if (target.length) {
                        $('html,body').animate({
                            scrollTop: target.offset().top
                        }, 1000);
                        return false;
                    }
                }
            });
        });
    </script>
    <!-- Navbar -->
    <script type="text/javascript">
        $(document).ready(function () {
            $('#nav').scrollToFixed();
        });
    </script>
    <!-- /Navbar-->
</body>

</html>