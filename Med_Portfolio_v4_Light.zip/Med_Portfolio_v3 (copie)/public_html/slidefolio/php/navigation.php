<div id="nav">
        <!-- Navigation -->
        <nav class="navbar navbar-new" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mobilemenu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand">Slidefolio By Med</a>
                </div>
                <div class="collapse navbar-collapse" id="mobilemenu">

                    <ul class="nav navbar-nav navbar-right text-center">
                        <li><a href="#top"><i class="service-icon fa fa-home"></i>&nbsp;Acceuil</a></li>
                        <li><a href="#about"><i class="service-icon fa fa-info"></i>&nbsp;Informations</a></li>
                        <li><a href="#services"><i class="service-icon fa fa-laptop"></i>&nbsp;Formation</a></li>
                        <li><a href="#portfolio"><i class="service-icon fa fa-camera"></i>&nbsp;Mes Projets</a></li>
                        <li><a href="#contact"><i class="service-icon fa fa-envelope"></i>&nbsp;Contact</a></li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- /Navigation -->
    </div>