 <!-- About -->
 <div id="about" class="about_me">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <h2>A propos de moi</h2>
                    <p class="lead">Actuellement en préparation du Titre de <strong>développeur web & web mobile <br> RNCP
                        niveau III (Bac+2).</strong><br>
                        Je recherche, <strong>un contrat de professionnalisation</strong> d’une durée de <strong>dix mois,</strong> dans lequel, je pourrai
                        <strong>consolider et développer mes compétences.</strong> 
                </div>
            </div>
        </div>
    </div>
    <!-- /About -->