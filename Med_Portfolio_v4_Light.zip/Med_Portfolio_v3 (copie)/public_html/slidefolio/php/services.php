<!-- Services -->
<div id="services" class="services">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 text-center">
                    <h2>Ma formation</h2>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 text-center">
                    <div class="service-item">
                        <i class="service-icon fa fa-camera-retro fa-3x"></i>
                        <h3>Mission</h3>
                        <p>Me tenir constament en eveille concernant les nouvelles technologies, m'investir a 200% dans
                            mon travail</p>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <div class="service-item">
                        <i class="service-icon fa fa-camera fa-3x"></i>
                        <h3>Objectifs</h3>
                        <p>Acquerir un maximum d'experience, anisi qu'un maximmum de connaisance afin de consolider mes
                            acquis.</p>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <div class="service-item">
                        <i class="service-icon fa fa-globe fa-3x"></i>
                        <h3>Ligne d'arriver</h3>
                        <p>Passage devant un jury pour valider le titre de Devellopeur Web & web Mobile
                            <br>Certification RNCP niveau III Bac+2</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Services -->