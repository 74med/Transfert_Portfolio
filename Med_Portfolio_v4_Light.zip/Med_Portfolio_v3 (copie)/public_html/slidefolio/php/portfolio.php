       <!-- Portfolio -->
       <div id="portfolio" class="portfolio">
        <div class="container">
            <div class="row push50">
                <div class="col-md-4 col-md-offset-4 text-center">
                    <h2>A votre disposition</h2>
                    <h3>
                        <span class="filter label label-default" data-filter="all">All</span>
                        <span class="filter label label-default" data-filter="competences">Compétences</span>
                        <span class="filter label label-default" data-filter="moi">infos</span>
                        <span class="filter label label-default" data-filter="autres">Utiles</span>
                    </h3>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="gallery">
                    <ul id="Grid" class="gcontainer">
                        <li class="col-md-4 col-sm-4 col-xs-12 mix moi " data-cat="moi">
                            <a data-toggle="modal" data-target="#moi" class="mix-cover">
                                <img class="horizontal" src="../slidefolio/img/first_images/2/a_propos_de_moi.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span class="title">A propos de
                                        moi</span></span>
                            </a>
                        </li>
                        <li class="col-md-4 col-sm-4 col-xs-12 mix autres" data-cat="project">
                            <a data-toggle="modal" data-target="#project" class="mix-cover">
                                <img class="horizontal" src="../slidefolio/img/first_images/2/trousse_a_projet.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span
                                        class="title">Projets</span></span>
                            </a>
                        </li>
                        <li class="col-md-4 col-sm-4 col-xs-12 mix competences " data-cat="System">
                            <a data-toggle="modal" data-target="#System" class="mix-cover">
                                <img class="horizontal" src="../slidefolio/img/first_images/2/systemes.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span
                                        class="title">Systèmes</span></span>
                            </a>
                        </li>
                        <li class="col-md-4 col-sm-4 col-xs-12 mix bw moi" data-cat="youtube">
                            <a data-toggle="modal" data-target="#youtube" class="mix-cover green">
                                <img class="vertical" src="../slidefolio/img/first_images/2/youtube.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span
                                        class="title">Youtube</span></span>
                            </a>
                        </li>
                        <li class="col-md-4 col-sm-4 col-xs-12 mix competences" data-cat="creations">
                            <a data-toggle="modal" data-target="#creations" class="mix-cover">
                                <img class="horizontal" src="../slidefolio/img/first_images/2/es_creations.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span
                                        class="title">Creations</span></span>
                            </a>
                        </li>
                        <li class="col-md-4 col-sm-4 col-xs-12 mix bw competences " data-cat="languages">
                            <a data-toggle="modal" data-target="#languages" class="mix-cover">
                                <img class="horizontal" src="../slidefolio/img/first_images/2/languages.png"
                                    alt="placeholder">
                                <span class="overlay"><span class="valign"></span><span
                                        class="title">Languages</span></span>
                            </a>
                        </li>
                    </ul>
                    <!-- Portfolio -->
                    <!--LANGUAGES-->
                    <!-- Load Photo in Modal -->
                    <div class="modal fade" id="languages" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="languages" src="img/Programmation/java3.png" />
                            </div>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0"
                                    aria-valuemax="100" style="width:30%">
                                    30%
                                </div>
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="languages" src="img/Programmation/javascript.jpg" />
                            </div>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0"
                                    aria-valuemax="100" style="width:35%">
                                    35%
                                </div>
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="languages" src="img/Programmation/python.png" />
                            </div>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0"
                                    aria-valuemax="100" style="width:20%">
                                    20%
                                </div>
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="languages" src="img/Programmation/HTML CSS.jpg" />
                            </div>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0"
                                    aria-valuemax="100" style="width:45%">
                                    45%
                                </div>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <!--LANGUAGES FIN-->

                <!-- creations-->
                <div class="modal fade" id="creations" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body">
                                <img class="thumbnail" alt="creations" src="img/Programmation/Bootstrap4.jpeg" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="creations" src="img/Programmation/Semantic-UI.png" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="creations" src="img/Programmation/jquery.jpg" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="creations" src="img/Programmation/WordPress.png" />
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <!--creations FIN -->


                <!--SYSTEM-->
                <div class="modal fade" id="System" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body">
                                <img class="thumbnail" alt="System" src="img/gif/giphy.gif" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="System" src="img/gif/ubuntu.gif" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="System" src="img/gif/windows10.gif" />
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="System" src="img/gif/apple.gif" />
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </div>
            <!--SYSTEM FIN-->


            <!--PROJECT-->
            <div class="modal fade" id="project" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" id="modal-center">
                    <div class="modal-content">
                        <div class="rotate">
                            <a href="https://github.com/74med" target="_blank"> <img class="rotate" alt="project"
                                    src="img/Programmation/Github.png" /></a>
                        </div>
                        <!-- </div> -->


                        <!--  TROUSSE A PROJET SUITE A REMPLIR  -->


                        <!--  <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"
                                    aria-hidden="true">&times;</button>
                                <h4 class="modal-title text-center">Fini</h4>
                            </div>
                            <div class="modal-body">
                                <img class="thumbnail" alt="project" src="img/Programmation/linux-ubuntu.png" />
                            </div>
                                                           <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                                    <h4 class="modal-title text-center">Projet 3</h4>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <img class="thumbnail" alt="project" src="img/"/>
                                                                </div>
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                                    <h4 class="modal-title text-center">Projet 4</h4>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <img class="thumbnail" alt="project" src="img/Programmation/github.png"/>
                                                                </div>-->
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <!--PROJECT FIN -->

            <!--GIT HUB-->
            <div class="modal fade" id="github" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <img class="thumbnail" alt="github" src="img/Programmation/Github.jpg" />
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <!--GIT HUB FIN-->


            <!--MOI-->
            <div class="modal fade" id="moi" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <img class="thumbnail" alt="moi" src="img/CV.png" />
                        </div>
                        <div class="modal-body">
                            <img class="thumbnail" alt="moi" src="img/" />
                        </div>
                        <div class="modal-body">
                            <img class="thumbnail" alt="moi" src="img/" />
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <!--MOI FIN-->


            <!--YOUTUBE-->
            <div class="modal fade" id="youtube" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="div-video">
                            <iframe width="890" height="600" src="https://www.youtube.com/embed/duo1clfO8IQ"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                        <div class="div-video2">
                            <iframe width="890" height="600" src="https://www.youtube.com/embed/O1-OqElZmUI"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                        <div class="div-video3">
                            <iframe width="890" height="600" src="https://www.youtube.com/embed/xAJxTrUYplo"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                        <div class="div-video">
                            <iframe width="890" height="600" src="https://www.youtube.com/embed/Ic3XeULIvE8"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe> </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <!--YOUTUBE FIN-->

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <!--TEST FIN-->

    <!-- /Load Photo in Modal -->
    </div>
    </div>
    </div>
    <!-- /Portfolio -->