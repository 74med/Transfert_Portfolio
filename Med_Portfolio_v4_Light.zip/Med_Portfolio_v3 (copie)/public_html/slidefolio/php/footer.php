 <!-- Footer -->
 <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center">
                    <h2>Merci à vous</h2>
                    <em style="color : wheat;">Copyright &copy; By Med 2019</em>
                </div>
            </div>
        </div>
    </footer>
    <!-- /Footer -->