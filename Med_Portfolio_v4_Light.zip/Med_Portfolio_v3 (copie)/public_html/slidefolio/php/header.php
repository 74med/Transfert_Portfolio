    <!-- Header Area -->
    <div id="top" class="header">
        <div class="vert-text">
            <img class="img-rounded" alt="Company Logo" src="./img/IrProfile.png" />
            <h2><em>MEHDI DRUELLE</em></h2>
            <ul class="list-inline">
                <li><a href="https://fr-fr.facebook.com/" target="_blank"><i class="fa fa-facebook fa-3x"></i></a></li>
                <li><a href="https://twitter.com/74mehdi74?lang=fr" target="_blank"><i
                            class="fa fa-twitter fa-3x"></i></a></li>
                <li><a href="https://github.com/74med" target="_blank"><i class="fa fa-github fa-3x"></i></a></li>
                <li><a href="https://www.linkedin.com/in/mehdi-druelle-9ba447162/" target="_blank"><i
                            class="fa fa-linkedin fa-3x"></i></a></li>
            </ul>
            <br>
            <a href="#about" class="btn btn-top">Plus D'infos</a>
        </div>
    </div>
    <!-- /Header Area -->