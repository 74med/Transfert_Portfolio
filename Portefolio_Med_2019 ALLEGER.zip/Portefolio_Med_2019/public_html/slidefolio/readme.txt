Thank You for Purchasing Slidefolio theme by Surfmandu.

What is inside the package. 
1. Bootstrap Css/JS
2. jQuery vegas, jQuery Validate, jQuery Mixitup
3. Sample Images and Template
4. Contact form with Validation



How do i change image of  Background Slideshow ?
- Open index.html in your editor and  Go to Line No. 395.

How do i change portfolio items ?
- Open index.html in your editor and  Go to Line No. 130.